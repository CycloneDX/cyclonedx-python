build via `python -m build`
